"use client"

import MatrixText from "../components/kokonutui/matrix-text"

export default function SyntheticV0PageForDeployment() {
  return <MatrixText />
}